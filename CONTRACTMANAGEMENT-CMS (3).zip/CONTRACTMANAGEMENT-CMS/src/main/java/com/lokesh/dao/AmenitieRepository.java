package com.lokesh.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lokesh.model.Amenitie;

public interface AmenitieRepository extends JpaRepository<Amenitie, Long> {

}

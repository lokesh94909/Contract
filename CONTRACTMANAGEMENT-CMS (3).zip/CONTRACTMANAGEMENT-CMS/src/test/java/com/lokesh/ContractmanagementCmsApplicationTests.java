package com.lokesh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContractmanagementCmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
